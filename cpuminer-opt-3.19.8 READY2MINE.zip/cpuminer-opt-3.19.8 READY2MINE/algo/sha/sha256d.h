#include "algo-gate-api.h"
#include <string.h>
#include <inttypes.h>
#include "sha256-hash.h"

void sha256d( void *hash, const void *data, int len );

